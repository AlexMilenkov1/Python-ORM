import os
import django
from django.db.models import Sum

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models
from main_app.models import Product, Category, Customer, Order, OrderProduct


def product_quantity_ordered():
    result = []

    total_quantity = (Product.objects
                      .annotate(total_ordered_quantity=Sum('orderproduct__quantity'))
                      .exclude(total_ordered_quantity=None)
                      .order_by('-total_ordered_quantity'))

    for product in total_quantity:
        result.append(f'Quantity ordered of {product.name}: {product.total_ordered_quantity}')

    return '\n'.join(result)


print(product_quantity_ordered())

